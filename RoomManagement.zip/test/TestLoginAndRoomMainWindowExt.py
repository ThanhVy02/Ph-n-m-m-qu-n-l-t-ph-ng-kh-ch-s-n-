from PyQt6.QtWidgets import QApplication, QMainWindow

from ui.extension.Room_Ext import Room_Ext

app=QApplication([])
mainwindow=QMainWindow()
myui=Room_Ext()
myui.setupUi(mainwindow)
myui.showWindow()
app.exec()