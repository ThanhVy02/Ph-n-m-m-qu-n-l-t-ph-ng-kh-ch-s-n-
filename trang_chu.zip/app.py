from PyQt6.QtWidgets import QApplication, QMainWindow
from ext import MainWindowExt

app=QApplication([])
mainwindow=QMainWindow()
myWindow= MainWindowExt()
myWindow.setupUi(mainwindow)
myWindow.show()
app.exec()